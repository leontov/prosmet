import { describe, expect, it } from "vitest";
import type { EstimateDraft, EstimateItem } from "@/lib/domain/estimate";
import {
  aggregateMarketPrices,
  canonicalWorkFromItem,
  inferPriceContext,
  normalizeUnit,
  observationContextHash,
  resolvePrice,
  type PriceObservation
} from "@/lib/domain/price-intelligence";

const item: EstimateItem = {
  id: "item-plaster",
  code: "",
  name: "Механизированная гипсовая штукатурка",
  unit: "м²",
  quantity: 358,
  norm: 1,
  coefficient: 1,
  unitPrice: 620,
  resourceType: "work",
  source: {
    label: "AI estimate",
    kind: "indicative",
    region: "Лениногорск",
    date: "2026-07-29",
    currency: "RUB",
    vatIncluded: false,
    deliveryIncluded: false,
    confidence: 60,
    confirmed: false
  },
  comment: "Средний слой 15 мм",
  warning: ""
};

const draft: EstimateDraft = {
  id: "estimate-1",
  title: "Штукатурка",
  objectName: "Квартира",
  customer: "Иванов",
  contractor: "",
  region: "Лениногорск",
  date: "2026-07-29",
  method: "commercial",
  currency: "RUB",
  status: "draft",
  revision: 1,
  technology: [{ id: "t1", title: "Подготовка", description: "", control: "", resources: [] }],
  sections: [{ id: "s1", title: "Работы", items: [item] }],
  overheadPercent: 0,
  profitPercent: 0,
  discountPercent: 0,
  vatPercent: 0,
  assumptions: [],
  warnings: [],
  reviewerNotes: [],
  updatedAt: "2026-07-29T00:00:00.000Z"
};

function observation(input: Partial<PriceObservation> & { id: string; price: number }): PriceObservation {
  const work = canonicalWorkFromItem(item, "2026-07-29T00:00:00.000Z");
  const context = inferPriceContext(item, draft);
  return {
    id: input.id,
    recordType: "price-observation",
    canonicalWorkId: work.id,
    rawName: item.name,
    normalizedName: work.normalizedName,
    price: input.price,
    currency: "RUB",
    unit: "м²",
    region: input.region ?? "Лениногорск",
    city: input.city ?? "Лениногорск",
    sourceType: input.sourceType ?? "regional",
    sourceId: input.sourceId ?? input.id,
    userId: input.userId ?? "",
    organizationId: input.organizationId ?? "",
    estimateId: input.estimateId ?? "",
    estimateRevision: input.estimateRevision ?? 0,
    estimateItemId: input.estimateItemId ?? "",
    observedAt: input.observedAt ?? "2026-07-29T00:00:00.000Z",
    validFrom: "",
    validTo: "",
    context: input.context ?? context,
    confidence: input.confidence ?? 85,
    status: input.status ?? "approved",
    contextHash: input.contextHash ?? observationContextHash(context),
    createdAt: input.createdAt ?? "2026-07-29T00:00:00.000Z"
  };
}

describe("Price Intelligence", () => {
  it("normalizes common construction units", () => {
    expect(normalizeUnit("м2")).toBe("м²");
    expect(normalizeUnit("пог. м")).toBe("п.м");
  });

  it("prefers a confirmed personal price over a regional value", () => {
    const insight = resolvePrice({
      item,
      draft,
      now: new Date("2026-07-29T12:00:00.000Z").getTime(),
      observations: [
        observation({ id: "regional", price: 650, sourceType: "regional", status: "approved" }),
        observation({ id: "personal", price: 700, sourceType: "personal", status: "sent_to_client", userId: "u1" })
      ]
    });
    expect(insight.selected?.id).toBe("personal");
    expect(insight.selected?.price).toBe(700);
  });

  it("keeps official prices outside the commercial market distribution", () => {
    const market = aggregateMarketPrices([
      observation({ id: "a", price: 600, userId: "u1" }),
      observation({ id: "b", price: 650, userId: "u2" }),
      observation({ id: "official", price: 300, sourceType: "official" })
    ]);
    expect(market?.sampleCount).toBe(2);
    expect(market?.median).toBe(625);
  });

  it("removes an extreme outlier from the trimmed market center", () => {
    const prices = [500, 550, 600, 620, 650, 680, 700, 750, 3000];
    const market = aggregateMarketPrices(
      prices.map((price, index) => observation({ id: `p${index}`, price, userId: `u${index}` }))
    );
    expect(market?.median).toBe(650);
    expect(market?.trimmedMean).toBeLessThan(800);
    expect(market?.p75).toBeLessThan(800);
  });

  it("requests research when no compatible price exists", () => {
    const insight = resolvePrice({ item, draft, observations: [] });
    expect(insight.requiresResearch).toBe(true);
    expect(insight.researchReason).toMatch(/не содержит/i);
  });
});
